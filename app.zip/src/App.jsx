import { useEffect, useState } from 'react'
import axios from 'axios'
import Tabla from './assets/components/Tabla'
import Button from './assets/components/Button'

function App() {
    const [ notas, setNotas ] = useState([])
    const [ notaEdit, setNotaEdit ] = useState({})

    useEffect(() => {
        axios.get('grade/index',{},{
        })
        .then(response => setNotas((notas) => response.data ))
        .catch(error => console.error(error.response.data.error))
    },[])

    const editNota = (item) => {
        setNotaEdit(item)
        console.log(notaEdit);
    }


    return (
        <>
            <div className='container mx-auto max-w-7xl'>
                <div className='flex justify-center items-center h-screen'>
                    <Tabla thead={
                        <tr>
                            <th>ID</th>
                            <th>ESTUDIANTE</th>
                            <th>MATERIA</th>
                            <th>PUNTEO</th>
                            <th width='100px' ></th>
                        </tr>
                    } 
                    tbody={
                        notas.map((nota,index) => (
                            <tr key={nota.id}>
                                <td>{nota.id}</td>
                                <td>{nota.studentName}</td>
                                <td>{nota.subject}</td>
                                <td>{nota.score}</td>
                                <td>
                                    <div className='flex gap-2'>
                                        <button onClick={() => editNota(nota)} className="btn btn-success shadow-green-800 rounded-full px-2 py-1">Editar</button>
                                        <Button text="Eliminar" className="btn-danger shadow-red-800 rounded-full px-2 py-1" />
                                    </div>
                                </td>
                            </tr>
                        ))
                    }
                    />
                </div>
            </div>
        </>
    )
}

export default App
